package com.mudik.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "pendaftaran_mudik")
public class PendaftaranMudik extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long pendaftaran_id;

    @ManyToOne
    public User user; // Akun Kepala Keluarga

    @ManyToOne
    public Rute rute;

    // 🔥 INI YANG BIKIN ERROR: Pastikan baris ini ada!
    // Relasi ke tabel Kendaraan
    @ManyToOne
    public Kendaraan kendaraan;

    public String nomor_kursi;

    // --- DATA PESERTA ---
    @NotBlank(message = "Nama peserta wajib diisi")
    public String nama_peserta;

    @Column(length = 16)
    @NotBlank(message = "NIK wajib 16 digit")
    public String nik_peserta;

    public String alasan_tolak;
    public String no_hp_peserta;
    public String jenis_kelamin;
    public LocalDate tanggal_lahir;
    public String kategori_penumpang; // Dewasa, Anak, Bayi

    // --- STATUS & VERIFIKASI ---
    public String status_pendaftaran; // MENUNGGU_VERIFIKASI, DITERIMA, DITOLAK

    // Fitur H-3 (Verifikasi Ulang)
    public boolean konfirmasi_h3;
    public LocalDateTime waktu_konfirmasi_h3;

    // Fitur Blacklist
    public boolean is_blacklisted;

    // ── LINK KONFIRMASI ──────────────────────────────────────────────
    // Diset true ketika admin menggunakan fitur "Kirim Link Konfirmasi" via WA H-3.
    // Tombol konfirmasi di dashboard user hanya aktif jika flag ini true.
    @Column(name = "link_konfirmasi_dikirim", nullable = false, columnDefinition = "boolean DEFAULT false")
    public boolean link_konfirmasi_dikirim = false;

    // ── LOCK KELUARGA ─────────────────────────────────────────────
    // Diset true jika salah satu anggota keluarga (1 akun) ditolak.
    // Anggota lain tidak bisa berubah status sampai masalah diselesaikan.
    // columnDefinition eksplisit agar Hibernate auto-DDL tidak gagal di PostgreSQL
    @Column(name = "is_family_locked", nullable = false, columnDefinition = "boolean DEFAULT false")
    public boolean is_family_locked = false;

    // Pesan alasan kunci yang ditampilkan ke admin di UI
    @Column(name = "alasan_lock", length = 500)
    public String alasan_lock;

    // Barang & Lainnya
    public String jenis_identitas;
    public String foto_identitas_path;
    public String alamat_rumah;
    public String kode_booking;

    // 🔥 TAMBAHAN UUID (PENTING BUAT LINK AMAN)
    @Column(unique = true, updatable = false)
    public String uuid;

    @CreationTimestamp
    public LocalDateTime created_at;

    // 🔥 GENERATE UUID & TANGGAL OTOMATIS
    @PrePersist
    public void prePersist() {
        if (uuid == null) {
            uuid = UUID.randomUUID().toString();
        }
        if (created_at == null) {
            created_at = LocalDateTime.now();
        }
        if (status_pendaftaran == null) {
            status_pendaftaran = "MENUNGGU VERIFIKASI";
        }
    }
}